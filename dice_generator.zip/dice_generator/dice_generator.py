from flask import Flask, request
from jinja2 import Environment, FileSystemLoader
import random

app = Flask(__name__)
@app.route('/', methods=['GET', 'POST'])
def formulari():
    environment = Environment(loader=FileSystemLoader("templates/"))
    # L'usuari ha clicat a Enviar
    if request.method == 'POST':
        template = environment.get_template("output_dice.html")
        output = request.form["output"]
        number_of_dice_6 = request.form["d6"]
        dice_list = []
        for i in range(int(number_of_dice_6)):
            num = random.randint(1,6)
            dice_list.append(num)

        # Info conté la informació que paso a la plantilla
        info = {"daus6":dice_list,"output":output}
        # Paso la info a la plantilla per generar el document final
        textFinal = template.render(info)
    else:
        # Carrego la plantilla
        template = environment.get_template("dice_form.html")
        info = {}
        textFinal = template.render()
    # Retornem com pàgina web el resultat final
    return textFinal